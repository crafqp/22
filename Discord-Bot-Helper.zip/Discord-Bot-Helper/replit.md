# Palestine Archive API

## Overview

A backend API service designed to power a Discord bot for the "Palestine Archive" project. The service aggregates and indexes metadata from multiple Palestinian digital archives (photos, videos, documents, books), providing searchable endpoints optimized for Discord embed integration. This is primarily a backend-only service with a minimal status page frontend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript (strict mode enabled)
- **Build System**: Custom build script using esbuild for server bundling and Vite for client assets
- **Entry Point**: `server/index.ts`

### API Design Pattern
- RESTful API endpoints prefixed with `/api`
- Response format optimized for Discord embeds with pagination (max 25 items per request)
- Endpoints include: `/api/search`, `/api/category/:type`, `/api/timeline/:year`, `/api/sources`, `/api/stats`, `/api/item/:id`
- Admin endpoints: `/api/admin/index`, `/api/admin/cache/clear`
- Webhook endpoints: `/api/webhooks/subscribe`, `/api/webhooks/unsubscribe/:id`, `/api/webhooks`

### Performance & Security
- **Rate Limiting**: 100 requests per minute per IP with X-RateLimit-* headers
- **Caching**: 5-minute TTL on search results for faster response times
- **Input Sanitization**: Search terms sanitized to prevent SQL injection
- **Advanced Search**: Boolean operators (AND, OR, NOT) and phrase matching with quotes

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts`
- **Database Connection**: Connection pool via `pg` library in `server/db.ts`
- **Migrations**: Managed via drizzle-kit, output to `/migrations`

### Data Model
- Two main tables: `archive_sources` (data providers) and `archive_items` (indexed content)
- Categories: photos, videos, documents, books (PostgreSQL enum)
- Rich metadata fields for Discord integration: thumbnails, durations, page counts, authors

### Content Indexing
- **Scraper Framework**: Abstract `ArchiveScraper` class in `server/scraper.ts`
- **Storage Interface**: `IStorage` interface with `DatabaseStorage` implementation
- Designed for multiple archive source integrations (Palestinian Museum, UNRWA, Poster Project)

### Frontend (Minimal)
- **Framework**: React 18 with Vite
- **UI Components**: shadcn/ui with Radix primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Purpose**: Simple status page showing API stats (not a user-facing application)
- **State Management**: TanStack Query for server state

### Path Aliases
- `@/*` → `./client/src/*`
- `@shared/*` → `./shared/*`
- `@assets` → `./attached_assets`

## External Dependencies

### Database
- **PostgreSQL**: Primary data store (requires `DATABASE_URL` environment variable)
- **Connection**: Uses `pg` Pool with Drizzle ORM

### Key NPM Packages
- `express`: HTTP server framework
- `drizzle-orm` + `drizzle-zod`: Database ORM and schema validation
- `zod`: Runtime type validation for API inputs
- `connect-pg-simple`: Session storage (if sessions are needed)

### Development Tools
- `tsx`: TypeScript execution for development
- `vite`: Frontend build and dev server
- `drizzle-kit`: Database migrations (`npm run db:push`)

### Replit-Specific
- `@replit/vite-plugin-runtime-error-modal`: Error overlay in development
- `@replit/vite-plugin-cartographer`: Development tooling
- `@replit/vite-plugin-dev-banner`: Development banner