import { useQuery } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import type { ArchiveStats } from "@shared/schema";

interface ApiResponse<T> {
  success: boolean;
  data: T;
}

function StatusPage() {
  const { data: statsResponse, isLoading } = useQuery<ApiResponse<ArchiveStats>>({
    queryKey: ["/api/stats"],
  });

  const stats = statsResponse?.data;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-lg w-full text-center space-y-6">
        <div className="space-y-2">
          <h1 className="text-2xl font-semibold text-foreground" data-testid="text-title">Palestine Archive API</h1>
          <p className="text-muted-foreground text-sm" data-testid="text-description">
            Backend service for Discord bot integration
          </p>
        </div>

        {isLoading ? (
          <div className="text-muted-foreground" data-testid="text-loading">Loading stats...</div>
        ) : stats ? (
          <div className="bg-card border border-card-border rounded-md p-4 space-y-4" data-testid="card-stats">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-left">
                <div className="text-muted-foreground">Total Items</div>
                <div className="text-foreground font-medium" data-testid="text-total-items">{stats.totalItems.toLocaleString()}</div>
              </div>
              <div className="text-left">
                <div className="text-muted-foreground">Sources</div>
                <div className="text-foreground font-medium" data-testid="text-sources">{stats.sources}</div>
              </div>
            </div>
            
            <div className="border-t border-border pt-4">
              <div className="text-muted-foreground text-xs mb-2">By Category</div>
              <div className="grid grid-cols-4 gap-2 text-xs">
                <div>
                  <div className="text-foreground font-medium" data-testid="text-photos-count">{stats.byCategory.photos}</div>
                  <div className="text-muted-foreground">Photos</div>
                </div>
                <div>
                  <div className="text-foreground font-medium" data-testid="text-videos-count">{stats.byCategory.videos}</div>
                  <div className="text-muted-foreground">Videos</div>
                </div>
                <div>
                  <div className="text-foreground font-medium" data-testid="text-documents-count">{stats.byCategory.documents}</div>
                  <div className="text-muted-foreground">Documents</div>
                </div>
                <div>
                  <div className="text-foreground font-medium" data-testid="text-books-count">{stats.byCategory.books}</div>
                  <div className="text-muted-foreground">Books</div>
                </div>
              </div>
            </div>

            {stats.lastUpdated && (
              <div className="text-xs text-muted-foreground" data-testid="text-last-updated">
                Last updated: {new Date(stats.lastUpdated).toLocaleString()}
              </div>
            )}
          </div>
        ) : (
          <div className="text-muted-foreground" data-testid="text-no-data">No data available</div>
        )}

        <div className="text-xs text-muted-foreground space-y-1">
          <div>API Documentation: <code className="bg-muted px-1 rounded">/api</code></div>
          <div>Health Check: <code className="bg-muted px-1 rounded">/api/health</code></div>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <StatusPage />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
