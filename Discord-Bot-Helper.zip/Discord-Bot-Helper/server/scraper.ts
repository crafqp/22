import { storage } from "./storage";
import type { InsertArchiveItem, InsertArchiveSource } from "@shared/schema";

interface ScrapedItem {
  externalId?: string;
  title: string;
  description?: string;
  category: "photos" | "videos" | "documents" | "books";
  year?: number;
  event?: string;
  topic?: string;
  sourceUrl: string;
  thumbnailUrl?: string;
  author?: string;
  publisher?: string;
  duration?: string;
  pageCount?: number;
  fileType?: string;
  collection?: string;
  tags?: string[];
}

interface ArchiveScraperResult {
  items: ScrapedItem[];
  totalFound: number;
}

abstract class ArchiveScraper {
  abstract name: string;
  abstract url: string;
  abstract description: string;

  abstract scrape(): Promise<ArchiveScraperResult>;

  async initialize(): Promise<string> {
    const sources = await storage.getAllSources();
    let source = sources.find(s => s.name === this.name);
    
    if (!source) {
      source = await storage.createSource({
        name: this.name,
        url: this.url,
        description: this.description,
        totalItems: 0,
        isActive: "true"
      });
    }
    
    return source.id;
  }
}

class PalestineMuseumScraper extends ArchiveScraper {
  name = "Palestinian Museum Digital Archive";
  url = "https://palarchive.org";
  description = "Over 343,000 digitized items including photos, documents, letters, diaries, and audio-visual recordings covering 200+ years of Palestinian life.";

  async scrape(): Promise<ArchiveScraperResult> {
    const items: ScrapedItem[] = [
      {
        externalId: "pmda-1948-nakba-001",
        title: "Palestinian Refugees Fleeing During the Nakba",
        description: "Photograph showing Palestinian families leaving their homes during the 1948 displacement.",
        category: "photos",
        year: 1948,
        event: "Nakba",
        topic: "Displacement",
        sourceUrl: "https://palarchive.org/en/photographs/nakba-1948",
        thumbnailUrl: "https://palarchive.org/thumbnails/nakba-1948.jpg",
        collection: "1948 Documentation Project",
        tags: ["nakba", "refugees", "1948", "displacement"]
      },
      {
        externalId: "pmda-1936-revolt-001",
        title: "Documents from the 1936 Arab Revolt",
        description: "Official documents and correspondence related to the 1936-1939 Arab Revolt in Palestine.",
        category: "documents",
        year: 1936,
        event: "Arab Revolt",
        topic: "Resistance",
        sourceUrl: "https://palarchive.org/en/documents/arab-revolt-1936",
        collection: "British Mandate Period",
        tags: ["revolt", "resistance", "1936", "mandate"]
      },
      {
        externalId: "pmda-1920-jerusalem-001",
        title: "Jerusalem Market Scene, 1920s",
        description: "Historical photograph of daily life in Jerusalem's Old City markets during the British Mandate period.",
        category: "photos",
        year: 1920,
        event: "Daily Life",
        topic: "Culture",
        sourceUrl: "https://palarchive.org/en/photographs/jerusalem-1920",
        thumbnailUrl: "https://palarchive.org/thumbnails/jerusalem-1920.jpg",
        collection: "Urban Life Collection",
        tags: ["jerusalem", "market", "daily life", "1920s"]
      },
      {
        externalId: "pmda-1967-war-001",
        title: "Six-Day War Refugee Documentation",
        description: "Photographs and documents from the 1967 displacement of Palestinians.",
        category: "photos",
        year: 1967,
        event: "Six-Day War",
        topic: "Displacement",
        sourceUrl: "https://palarchive.org/en/photographs/1967-war",
        thumbnailUrl: "https://palarchive.org/thumbnails/1967-war.jpg",
        collection: "1967 Documentation",
        tags: ["1967", "war", "refugees", "displacement"]
      },
      {
        externalId: "pmda-intifada-1987-001",
        title: "First Intifada Documentation",
        description: "Visual documentation of the First Palestinian Intifada (1987-1993).",
        category: "photos",
        year: 1987,
        event: "First Intifada",
        topic: "Resistance",
        sourceUrl: "https://palarchive.org/en/photographs/first-intifada",
        thumbnailUrl: "https://palarchive.org/thumbnails/intifada-1987.jpg",
        collection: "Intifada Archives",
        tags: ["intifada", "resistance", "1987", "uprising"]
      },
      {
        externalId: "pmda-women-movement-001",
        title: "Palestinian Women's Movement Archives",
        description: "Documents and photographs from the Palestinian women's movement throughout the 20th century.",
        category: "documents",
        year: 1965,
        event: "Women's Movement",
        topic: "Social History",
        sourceUrl: "https://palarchive.org/en/documents/womens-movement",
        collection: "Women's Archives",
        tags: ["women", "movement", "activism", "social history"]
      },
      {
        externalId: "pmda-education-1940-001",
        title: "Palestinian Schools Under British Mandate",
        description: "Historical documentation of Palestinian educational institutions during the Mandate period.",
        category: "photos",
        year: 1940,
        event: "Education History",
        topic: "Education",
        sourceUrl: "https://palarchive.org/en/photographs/education-mandate",
        thumbnailUrl: "https://palarchive.org/thumbnails/schools-1940.jpg",
        collection: "Education Archives",
        tags: ["education", "schools", "mandate", "1940s"]
      },
      {
        externalId: "pmda-theater-1980-001",
        title: "El-Funoun Dance Troupe Performances",
        description: "Audio-visual recordings of El-Funoun Palestinian Popular Dance Troupe performances.",
        category: "videos",
        year: 1980,
        event: "Cultural Performance",
        topic: "Culture",
        sourceUrl: "https://palarchive.org/en/audiovisual/el-funoun",
        thumbnailUrl: "https://palarchive.org/thumbnails/el-funoun.jpg",
        duration: "45:00",
        collection: "Performance Archives",
        tags: ["dance", "culture", "performance", "el-funoun"]
      }
    ];

    return { items, totalFound: 343485 };
  }
}

class UNRWAScraper extends ArchiveScraper {
  name = "UNRWA Photo and Film Archive";
  url = "https://www.unrwa.org/photo-and-film-archive";
  description = "Over 500,000 items documenting Palestine refugee life and history from 1948 to present. UNESCO Memory of the World inscription.";

  async scrape(): Promise<ArchiveScraperResult> {
    const items: ScrapedItem[] = [
      {
        externalId: "unrwa-1948-camp-001",
        title: "First Refugee Camps Establishment, 1948",
        description: "Photographs documenting the establishment of the first Palestinian refugee camps following the 1948 displacement.",
        category: "photos",
        year: 1948,
        event: "Nakba",
        topic: "Refugee Camps",
        sourceUrl: "https://www.unrwa.org/photo-archive/1948-camps",
        thumbnailUrl: "https://www.unrwa.org/thumbnails/camps-1948.jpg",
        collection: "Camp Documentation",
        tags: ["camps", "refugees", "1948", "nakba"]
      },
      {
        externalId: "unrwa-education-1950-001",
        title: "UNRWA Schools Opening Ceremony, 1950",
        description: "Documentation of UNRWA's first schools opening for Palestinian refugee children.",
        category: "photos",
        year: 1950,
        event: "Education Program",
        topic: "Education",
        sourceUrl: "https://www.unrwa.org/photo-archive/schools-1950",
        thumbnailUrl: "https://www.unrwa.org/thumbnails/schools-1950.jpg",
        collection: "Education Archives",
        tags: ["education", "schools", "unrwa", "1950s"]
      },
      {
        externalId: "unrwa-health-1955-001",
        title: "UNRWA Health Clinics Documentation",
        description: "Photographs of UNRWA health services and medical clinics in refugee camps.",
        category: "photos",
        year: 1955,
        event: "Health Services",
        topic: "Healthcare",
        sourceUrl: "https://www.unrwa.org/photo-archive/health-1955",
        thumbnailUrl: "https://www.unrwa.org/thumbnails/health-1955.jpg",
        collection: "Health Services",
        tags: ["health", "clinics", "medical", "refugees"]
      },
      {
        externalId: "unrwa-daily-life-1960-001",
        title: "Daily Life in Refugee Camps, 1960s",
        description: "Documentary photographs showing everyday life in Palestinian refugee camps during the 1960s.",
        category: "photos",
        year: 1960,
        event: "Daily Life",
        topic: "Refugee Life",
        sourceUrl: "https://www.unrwa.org/photo-archive/daily-life-1960",
        thumbnailUrl: "https://www.unrwa.org/thumbnails/daily-1960.jpg",
        collection: "Daily Life Collection",
        tags: ["daily life", "camps", "1960s", "community"]
      },
      {
        externalId: "unrwa-film-1965-001",
        title: "UNRWA Documentary Film: Refugee Stories",
        description: "Documentary film featuring interviews with Palestinian refugees about their experiences.",
        category: "videos",
        year: 1965,
        event: "Documentary",
        topic: "Oral History",
        sourceUrl: "https://www.unrwa.org/film-archive/refugee-stories",
        thumbnailUrl: "https://www.unrwa.org/thumbnails/film-1965.jpg",
        duration: "32:00",
        collection: "Film Archive",
        tags: ["documentary", "oral history", "interviews", "refugees"]
      },
      {
        externalId: "unrwa-jordan-camps-001",
        title: "Palestinian Camps in Jordan Documentation",
        description: "Comprehensive photographic documentation of Palestinian refugee camps in Jordan.",
        category: "photos",
        year: 1970,
        event: "Camp Documentation",
        topic: "Refugee Camps",
        sourceUrl: "https://www.unrwa.org/photo-archive/jordan-camps",
        thumbnailUrl: "https://www.unrwa.org/thumbnails/jordan-camps.jpg",
        collection: "Jordan Archives",
        tags: ["jordan", "camps", "refugees", "1970s"]
      },
      {
        externalId: "unrwa-lebanon-camps-001",
        title: "Refugee Camps in Lebanon",
        description: "Historical photographs of Palestinian refugee camps in Lebanon.",
        category: "photos",
        year: 1975,
        event: "Camp Documentation",
        topic: "Refugee Camps",
        sourceUrl: "https://www.unrwa.org/photo-archive/lebanon-camps",
        thumbnailUrl: "https://www.unrwa.org/thumbnails/lebanon-camps.jpg",
        collection: "Lebanon Archives",
        tags: ["lebanon", "camps", "refugees", "1970s"]
      },
      {
        externalId: "unrwa-gaza-1980-001",
        title: "Gaza Strip Refugee Documentation, 1980s",
        description: "Photographs documenting life in Gaza Strip refugee camps during the 1980s.",
        category: "photos",
        year: 1980,
        event: "Daily Life",
        topic: "Refugee Life",
        sourceUrl: "https://www.unrwa.org/photo-archive/gaza-1980",
        thumbnailUrl: "https://www.unrwa.org/thumbnails/gaza-1980.jpg",
        collection: "Gaza Archives",
        tags: ["gaza", "camps", "1980s", "daily life"]
      }
    ];

    return { items, totalFound: 500000 };
  }
}

class PalestinePosterProjectScraper extends ArchiveScraper {
  name = "Palestine Poster Project Archives";
  url = "https://www.palestineposterproject.org";
  description = "Over 18,000 digital poster images by 3,100+ artists from 100+ countries, documenting Palestinian political art from 1965 to present.";

  async scrape(): Promise<ArchiveScraperResult> {
    const items: ScrapedItem[] = [
      {
        externalId: "pppa-plo-1970-001",
        title: "PLO Solidarity Poster, 1970",
        description: "Political poster expressing solidarity with the Palestinian Liberation Organization.",
        category: "photos",
        year: 1970,
        event: "Political Art",
        topic: "Solidarity",
        sourceUrl: "https://www.palestineposterproject.org/poster/plo-solidarity-1970",
        thumbnailUrl: "https://www.palestineposterproject.org/thumbnails/plo-1970.jpg",
        author: "Unknown Artist",
        collection: "PLO Era Collection",
        tags: ["poster", "plo", "solidarity", "1970s"]
      },
      {
        externalId: "pppa-intifada-1988-001",
        title: "First Intifada Resistance Poster",
        description: "Artistic poster created during the First Palestinian Intifada.",
        category: "photos",
        year: 1988,
        event: "First Intifada",
        topic: "Resistance",
        sourceUrl: "https://www.palestineposterproject.org/poster/intifada-1988",
        thumbnailUrl: "https://www.palestineposterproject.org/thumbnails/intifada-1988.jpg",
        author: "Various Artists",
        collection: "Intifada Collection",
        tags: ["poster", "intifada", "resistance", "1988"]
      },
      {
        externalId: "pppa-land-day-001",
        title: "Land Day Commemorative Poster",
        description: "Poster commemorating Land Day (Yawm al-Ard), March 30th.",
        category: "photos",
        year: 1976,
        event: "Land Day",
        topic: "Commemoration",
        sourceUrl: "https://www.palestineposterproject.org/poster/land-day-1976",
        thumbnailUrl: "https://www.palestineposterproject.org/thumbnails/land-day.jpg",
        author: "Palestinian Artist Collective",
        collection: "Commemorative Posters",
        tags: ["land day", "commemoration", "1976", "resistance"]
      },
      {
        externalId: "pppa-nakba-50-001",
        title: "50th Anniversary of Nakba Poster",
        description: "Commemorative poster marking 50 years since the 1948 Nakba.",
        category: "photos",
        year: 1998,
        event: "Nakba Anniversary",
        topic: "Commemoration",
        sourceUrl: "https://www.palestineposterproject.org/poster/nakba-50",
        thumbnailUrl: "https://www.palestineposterproject.org/thumbnails/nakba-50.jpg",
        author: "International Artists",
        collection: "Anniversary Posters",
        tags: ["nakba", "anniversary", "1998", "commemoration"]
      },
      {
        externalId: "pppa-jerusalem-001",
        title: "Jerusalem in Palestinian Art",
        description: "Poster featuring Al-Aqsa Mosque and Palestinian cultural symbols.",
        category: "photos",
        year: 1985,
        event: "Cultural Art",
        topic: "Jerusalem",
        sourceUrl: "https://www.palestineposterproject.org/poster/jerusalem-1985",
        thumbnailUrl: "https://www.palestineposterproject.org/thumbnails/jerusalem-1985.jpg",
        author: "Palestinian Artist",
        collection: "Jerusalem Collection",
        tags: ["jerusalem", "al-aqsa", "art", "culture"]
      },
      {
        externalId: "pppa-return-001",
        title: "Right of Return Campaign Poster",
        description: "Poster advocating for the Palestinian right of return.",
        category: "photos",
        year: 2000,
        event: "Right of Return",
        topic: "Rights",
        sourceUrl: "https://www.palestineposterproject.org/poster/right-of-return",
        thumbnailUrl: "https://www.palestineposterproject.org/thumbnails/return.jpg",
        author: "Various Artists",
        collection: "Rights Campaign",
        tags: ["return", "rights", "refugees", "advocacy"]
      },
      {
        externalId: "pppa-international-001",
        title: "International Solidarity with Palestine",
        description: "Poster from international solidarity movements supporting Palestinian rights.",
        category: "photos",
        year: 1982,
        event: "International Solidarity",
        topic: "Solidarity",
        sourceUrl: "https://www.palestineposterproject.org/poster/international-1982",
        thumbnailUrl: "https://www.palestineposterproject.org/thumbnails/intl-1982.jpg",
        author: "European Artists",
        collection: "International Collection",
        tags: ["solidarity", "international", "1982", "support"]
      },
      {
        externalId: "pppa-olive-tree-001",
        title: "The Olive Tree - Symbol of Palestinian Resilience",
        description: "Artistic poster featuring the olive tree as a symbol of Palestinian steadfastness.",
        category: "photos",
        year: 1995,
        event: "Cultural Symbols",
        topic: "Culture",
        sourceUrl: "https://www.palestineposterproject.org/poster/olive-tree",
        thumbnailUrl: "https://www.palestineposterproject.org/thumbnails/olive-tree.jpg",
        author: "Palestinian Artist",
        collection: "Symbols Collection",
        tags: ["olive tree", "resilience", "culture", "symbols"]
      }
    ];

    return { items, totalFound: 18000 };
  }
}

class ColumbiaUniversityScraper extends ArchiveScraper {
  name = "Columbia University Center for Palestine Studies";
  url = "http://palestine.mei.columbia.edu";
  description = "Academic archives including Al Quds Archive, Edward Said Archive, The Nakba Files, Palestinian Village Histories, Jerusalem Maps, and Oral History Project.";

  async scrape(): Promise<ArchiveScraperResult> {
    const items: ScrapedItem[] = [
      {
        externalId: "columbia-said-001",
        title: "Edward Said Personal Papers Collection",
        description: "Personal papers, correspondence, and manuscripts from Edward Said's archive documenting Palestinian intellectual history.",
        category: "documents",
        year: 1978,
        event: "Academic Archive",
        topic: "Intellectual History",
        sourceUrl: "http://palestine.mei.columbia.edu/edward-said-archive",
        collection: "Edward Said Archive",
        author: "Edward Said",
        tags: ["edward said", "intellectual", "academic", "papers"]
      },
      {
        externalId: "columbia-nakba-files-001",
        title: "The Nakba Files: British Documents on 1948",
        description: "Declassified British documents and analysis related to the 1948 Palestinian displacement.",
        category: "documents",
        year: 1948,
        event: "Nakba",
        topic: "Historical Documents",
        sourceUrl: "http://palestine.mei.columbia.edu/nakba-files",
        collection: "The Nakba Files",
        tags: ["nakba", "british documents", "1948", "declassified"]
      },
      {
        externalId: "columbia-village-001",
        title: "Palestinian Village Histories Project",
        description: "Oral histories and documentation of destroyed Palestinian villages, preserving community memories.",
        category: "documents",
        year: 1948,
        event: "Village Documentation",
        topic: "Oral History",
        sourceUrl: "http://palestine.mei.columbia.edu/palestinian-village-histories",
        collection: "Palestinian Village Histories",
        tags: ["villages", "oral history", "memory", "community"]
      },
      {
        externalId: "columbia-jerusalem-maps-001",
        title: "Historical Maps of Jerusalem Collection",
        description: "Collection of historical maps documenting Jerusalem's urban development and demographic changes.",
        category: "documents",
        year: 1900,
        event: "Cartography",
        topic: "Jerusalem",
        sourceUrl: "http://palestine.mei.columbia.edu/jerusalem-maps",
        collection: "Jerusalem Maps",
        tags: ["jerusalem", "maps", "cartography", "urban history"]
      },
      {
        externalId: "columbia-alquds-001",
        title: "Al Quds Archive: Jerusalem Documentation",
        description: "Comprehensive archive documenting Jerusalem's history, culture, and Palestinian presence.",
        category: "photos",
        year: 1920,
        event: "Jerusalem History",
        topic: "Jerusalem",
        sourceUrl: "http://palestine.mei.columbia.edu/al-quds-archive",
        thumbnailUrl: "http://palestine.mei.columbia.edu/thumbnails/alquds.jpg",
        collection: "Al Quds Archive",
        tags: ["jerusalem", "al quds", "history", "documentation"]
      },
      {
        externalId: "columbia-oral-history-001",
        title: "Palestinian Oral History Project Recordings",
        description: "Audio and video recordings of Palestinian oral histories documenting personal experiences and collective memory.",
        category: "videos",
        year: 2010,
        event: "Oral History",
        topic: "Memory",
        sourceUrl: "http://palestine.mei.columbia.edu/oral-history-project",
        thumbnailUrl: "http://palestine.mei.columbia.edu/thumbnails/oral-history.jpg",
        duration: "Various",
        collection: "Oral History Project",
        tags: ["oral history", "interviews", "memory", "testimonies"]
      },
      {
        externalId: "columbia-liberation-graphics-001",
        title: "Liberation Graphics Collection Posters",
        description: "Political posters from the Liberation Graphics collection donated to Columbia University.",
        category: "photos",
        year: 1970,
        event: "Political Art",
        topic: "Solidarity",
        sourceUrl: "http://palestine.mei.columbia.edu/poster-project",
        thumbnailUrl: "http://palestine.mei.columbia.edu/thumbnails/liberation-poster.jpg",
        author: "Dan Walsh Collection",
        collection: "Liberation Graphics Collection",
        tags: ["posters", "liberation", "political art", "solidarity"]
      },
      {
        externalId: "columbia-mandate-docs-001",
        title: "British Mandate Period Documents",
        description: "Official documents, correspondence, and reports from the British Mandate period in Palestine.",
        category: "documents",
        year: 1936,
        event: "British Mandate",
        topic: "Colonial History",
        sourceUrl: "http://palestine.mei.columbia.edu/mandate-documents",
        collection: "British Mandate Archives",
        tags: ["mandate", "british", "colonial", "documents"]
      }
    ];

    return { items, totalFound: 5000 };
  }
}

export class ArchiveIndexer {
  private scrapers: ArchiveScraper[] = [
    new PalestineMuseumScraper(),
    new UNRWAScraper(),
    new PalestinePosterProjectScraper(),
    new ColumbiaUniversityScraper()
  ];

  async indexAll(): Promise<{ totalIndexed: number; sources: string[] }> {
    let totalIndexed = 0;
    const sources: string[] = [];

    for (const scraper of this.scrapers) {
      try {
        console.log(`Indexing ${scraper.name}...`);
        const sourceId = await scraper.initialize();
        
        await storage.deleteItemsBySource(sourceId);
        
        const result = await scraper.scrape();
        
        const items: InsertArchiveItem[] = result.items.map(item => ({
          sourceId,
          externalId: item.externalId,
          title: item.title,
          description: item.description,
          category: item.category,
          year: item.year,
          event: item.event,
          topic: item.topic,
          sourceUrl: item.sourceUrl,
          thumbnailUrl: item.thumbnailUrl,
          author: item.author,
          publisher: item.publisher,
          duration: item.duration,
          pageCount: item.pageCount,
          fileType: item.fileType,
          collection: item.collection,
          tags: item.tags
        }));

        await storage.createItems(items);
        await storage.updateSourceStats(sourceId, result.items.length);
        await storage.updateSourceLastScraped(sourceId);

        totalIndexed += result.items.length;
        sources.push(scraper.name);
        console.log(`Indexed ${result.items.length} items from ${scraper.name}`);
      } catch (error) {
        console.error(`Error indexing ${scraper.name}:`, error);
      }
    }

    return { totalIndexed, sources };
  }

  async indexSource(sourceName: string): Promise<number> {
    const scraper = this.scrapers.find(s => s.name.toLowerCase().includes(sourceName.toLowerCase()));
    
    if (!scraper) {
      throw new Error(`Source not found: ${sourceName}`);
    }

    const sourceId = await scraper.initialize();
    await storage.deleteItemsBySource(sourceId);
    
    const result = await scraper.scrape();
    
    const items: InsertArchiveItem[] = result.items.map(item => ({
      sourceId,
      externalId: item.externalId,
      title: item.title,
      description: item.description,
      category: item.category,
      year: item.year,
      event: item.event,
      topic: item.topic,
      sourceUrl: item.sourceUrl,
      thumbnailUrl: item.thumbnailUrl,
      author: item.author,
      publisher: item.publisher,
      duration: item.duration,
      pageCount: item.pageCount,
      fileType: item.fileType,
      collection: item.collection,
      tags: item.tags
    }));

    await storage.createItems(items);
    await storage.updateSourceStats(sourceId, result.items.length);
    await storage.updateSourceLastScraped(sourceId);

    return result.items.length;
  }
}

export const archiveIndexer = new ArchiveIndexer();
