import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage, clearCache } from "./storage";
import { archiveIndexer } from "./scraper";
import {
  searchQuerySchema,
  type ApiResponse,
  type DiscordEmbedItem,
  type ArchiveStats,
  type ArchiveSource,
} from "@shared/schema";
import { z } from "zod";

const rateLimitStore = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT = 100;
const RATE_WINDOW = 60 * 1000;

function rateLimiter(req: Request, res: Response, next: NextFunction): void {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  
  let record = rateLimitStore.get(ip);
  
  if (!record || now > record.resetTime) {
    record = { count: 1, resetTime: now + RATE_WINDOW };
    rateLimitStore.set(ip, record);
  } else {
    record.count++;
  }
  
  res.setHeader("X-RateLimit-Limit", RATE_LIMIT);
  res.setHeader("X-RateLimit-Remaining", Math.max(0, RATE_LIMIT - record.count));
  res.setHeader("X-RateLimit-Reset", record.resetTime);
  
  if (record.count > RATE_LIMIT) {
    res.status(429).json({
      success: false,
      error: "Rate limit exceeded. Please try again later.",
      retryAfter: Math.ceil((record.resetTime - now) / 1000)
    });
    return;
  }
  
  next();
}

const webhookSubscribers = new Map<string, { url: string; events: string[]; createdAt: Date }>();

async function notifyWebhookSubscribers(event: string, data: any): Promise<void> {
  const subscribers = Array.from(webhookSubscribers.entries())
    .filter(([_, sub]) => sub.events.includes(event));
  
  for (const [id, subscriber] of subscribers) {
    try {
      await fetch(subscriber.url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          event,
          data,
          timestamp: new Date().toISOString()
        })
      });
    } catch (error) {
      console.error(`Failed to notify webhook ${id}:`, error);
    }
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.use("/api", rateLimiter);

  // API Documentation endpoint
  app.get("/api", (req, res) => {
    const docs = {
      name: "Palestine Archive API",
      version: "1.0.0",
      description: "Backend API service for the Palestine Archive Discord bot. Aggregates and indexes metadata from multiple Palestine digital archives.",
      endpoints: {
        search: {
          path: "/api/search",
          method: "GET",
          description: "Full-text search across all archive items",
          parameters: {
            q: "Search query (optional)",
            category: "Filter by category: photos, videos, documents, books (optional)",
            year: "Filter by specific year (optional)",
            yearFrom: "Filter by year range start (optional)",
            yearTo: "Filter by year range end (optional)",
            event: "Filter by event name (optional)",
            topic: "Filter by topic (optional)",
            source: "Filter by source ID (optional)",
            page: "Page number, default 1",
            limit: "Results per page, max 25, default 10"
          },
          example: "/api/search?q=nakba&category=photos&yearFrom=1948&yearTo=1950"
        },
        category: {
          path: "/api/category/:type",
          method: "GET",
          description: "Browse items by category",
          parameters: {
            type: "Category type: photos, videos, documents, books",
            page: "Page number",
            limit: "Results per page"
          },
          example: "/api/category/photos?page=1&limit=10"
        },
        timeline: {
          path: "/api/timeline/:year",
          method: "GET",
          description: "Get items by year or year range",
          parameters: {
            year: "Specific year or 'range' with yearFrom and yearTo",
            yearFrom: "Start year for range (when year=range)",
            yearTo: "End year for range (when year=range)"
          },
          examples: [
            "/api/timeline/1948",
            "/api/timeline/range?yearFrom=1948&yearTo=1967"
          ]
        },
        sources: {
          path: "/api/sources",
          method: "GET",
          description: "List all integrated archive sources"
        },
        stats: {
          path: "/api/stats",
          method: "GET",
          description: "Get total indexed items and statistics"
        },
        item: {
          path: "/api/item/:id",
          method: "GET",
          description: "Get a specific archive item by ID"
        }
      },
      advancedSearch: {
        description: "Advanced search supports Boolean operators and phrase matching",
        operators: {
          AND: "Default operator between terms. Example: nakba AND refugees",
          OR: "Match any term. Example: nakba OR intifada",
          NOT: "Exclude terms with minus prefix. Example: nakba -1967",
          phrase: "Exact phrase in quotes. Example: \"refugee camps\""
        },
        examples: [
          "/api/search?q=nakba AND refugees",
          "/api/search?q=jerusalem OR intifada",
          "/api/search?q=\"daily life\" -war",
          "/api/search?q=\"first intifada\" category=photos"
        ]
      },
      webhooks: {
        subscribe: {
          path: "/api/webhooks/subscribe",
          method: "POST",
          description: "Subscribe to webhook notifications",
          body: { url: "Webhook URL", events: ["new_items", "index_complete", "source_added"] }
        },
        unsubscribe: {
          path: "/api/webhooks/unsubscribe/:id",
          method: "DELETE",
          description: "Unsubscribe from webhook notifications"
        },
        list: {
          path: "/api/webhooks",
          method: "GET",
          description: "List active webhook subscriptions"
        }
      },
      admin: {
        index: {
          path: "/api/admin/index",
          method: "POST",
          description: "Trigger full archive re-indexing"
        },
        indexSource: {
          path: "/api/admin/index/:source",
          method: "POST",
          description: "Trigger indexing for specific source"
        },
        clearCache: {
          path: "/api/admin/cache/clear",
          method: "POST",
          description: "Clear search result cache"
        }
      },
      rateLimiting: {
        limit: "100 requests per minute per IP",
        headers: {
          "X-RateLimit-Limit": "Max requests per window",
          "X-RateLimit-Remaining": "Remaining requests",
          "X-RateLimit-Reset": "Window reset timestamp"
        }
      },
      discordBotIntegration: {
        note: "All responses are optimized for Discord embeds with max 25 results per page",
        responseFormat: {
          success: "boolean",
          data: "array of items or single item",
          pagination: {
            page: "current page",
            limit: "items per page",
            total: "total items",
            totalPages: "total pages",
            hasNext: "boolean"
          }
        },
        caching: "Results cached for 5 minutes for faster response times"
      },
      sources: [
        "Palestinian Museum Digital Archive (343,000+ items)",
        "UNRWA Photo and Film Archive (500,000+ items)",
        "Palestine Poster Project Archives (18,000+ posters)",
        "Columbia University Center for Palestine Studies"
      ]
    };
    res.json(docs);
  });

  // Search endpoint - main Discord bot interface
  app.get("/api/search", async (req, res) => {
    try {
      const query = searchQuerySchema.parse(req.query);
      const { items, total } = await storage.searchItems(query);
      
      const totalPages = Math.ceil(total / query.limit);
      const response: ApiResponse<DiscordEmbedItem[]> = {
        success: true,
        data: items,
        pagination: {
          page: query.page,
          limit: query.limit,
          total,
          totalPages,
          hasNext: query.page < totalPages
        }
      };
      
      res.json(response);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          success: false,
          error: "Invalid query parameters",
          details: error.errors
        });
        return;
      }
      console.error("Search error:", error);
      res.status(500).json({
        success: false,
        error: "Internal server error"
      });
    }
  });

  // Category browsing endpoint
  app.get("/api/category/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const validCategories = ["photos", "videos", "documents", "books"];
      
      if (!validCategories.includes(type)) {
        res.status(400).json({
          success: false,
          error: `Invalid category. Must be one of: ${validCategories.join(", ")}`
        });
        return;
      }

      const page = parseInt(req.query.page as string) || 1;
      const limit = Math.min(parseInt(req.query.limit as string) || 10, 25);

      const { items, total } = await storage.getItemsByCategory(type, page, limit);
      const totalPages = Math.ceil(total / limit);

      const response: ApiResponse<DiscordEmbedItem[]> = {
        success: true,
        data: items,
        pagination: {
          page,
          limit,
          total,
          totalPages,
          hasNext: page < totalPages
        }
      };

      res.json(response);
    } catch (error) {
      console.error("Category error:", error);
      res.status(500).json({
        success: false,
        error: "Internal server error"
      });
    }
  });

  // Timeline endpoint - by year or year range
  app.get("/api/timeline/:year", async (req, res) => {
    try {
      const { year } = req.params;
      const page = parseInt(req.query.page as string) || 1;
      const limit = Math.min(parseInt(req.query.limit as string) || 10, 25);

      let items: DiscordEmbedItem[];
      let total: number;

      if (year === "range") {
        const yearFrom = parseInt(req.query.yearFrom as string);
        const yearTo = parseInt(req.query.yearTo as string);

        if (!yearFrom || !yearTo) {
          res.status(400).json({
            success: false,
            error: "yearFrom and yearTo are required for range queries"
          });
          return;
        }

        const result = await storage.getItemsByYearRange(yearFrom, yearTo, page, limit);
        items = result.items;
        total = result.total;
      } else {
        const yearNum = parseInt(year);
        if (isNaN(yearNum)) {
          res.status(400).json({
            success: false,
            error: "Invalid year format"
          });
          return;
        }

        const result = await storage.getItemsByYear(yearNum, page, limit);
        items = result.items;
        total = result.total;
      }

      const totalPages = Math.ceil(total / limit);

      const response: ApiResponse<DiscordEmbedItem[]> = {
        success: true,
        data: items,
        pagination: {
          page,
          limit,
          total,
          totalPages,
          hasNext: page < totalPages
        }
      };

      res.json(response);
    } catch (error) {
      console.error("Timeline error:", error);
      res.status(500).json({
        success: false,
        error: "Internal server error"
      });
    }
  });

  // Sources list endpoint
  app.get("/api/sources", async (req, res) => {
    try {
      const sources = await storage.getAllSources();
      
      const response: ApiResponse<ArchiveSource[]> = {
        success: true,
        data: sources
      };

      res.json(response);
    } catch (error) {
      console.error("Sources error:", error);
      res.status(500).json({
        success: false,
        error: "Internal server error"
      });
    }
  });

  // Statistics endpoint
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      
      const response: ApiResponse<ArchiveStats> = {
        success: true,
        data: stats
      };

      res.json(response);
    } catch (error) {
      console.error("Stats error:", error);
      res.status(500).json({
        success: false,
        error: "Internal server error"
      });
    }
  });

  // Get single item by ID
  app.get("/api/item/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const item = await storage.getItem(id);

      if (!item) {
        res.status(404).json({
          success: false,
          error: "Item not found"
        });
        return;
      }

      const sources = await storage.getAllSources();
      const source = sources.find(s => s.id === item.sourceId);

      const discordItem: DiscordEmbedItem = {
        id: item.id,
        title: item.title,
        description: item.description || "",
        year: item.year,
        category: item.category,
        source: source?.name || "Unknown",
        sourceUrl: item.sourceUrl,
        thumbnailUrl: item.thumbnailUrl,
        event: item.event,
        topic: item.topic,
        author: item.author,
        collection: item.collection
      };

      const response: ApiResponse<DiscordEmbedItem> = {
        success: true,
        data: discordItem
      };

      res.json(response);
    } catch (error) {
      console.error("Item error:", error);
      res.status(500).json({
        success: false,
        error: "Internal server error"
      });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({
      status: "healthy",
      timestamp: new Date().toISOString()
    });
  });

  // Admin endpoint - trigger full archive indexing
  app.post("/api/admin/index", async (req, res) => {
    try {
      console.log("Starting full archive indexing...");
      const result = await archiveIndexer.indexAll();
      
      res.json({
        success: true,
        message: "Archive indexing completed",
        totalIndexed: result.totalIndexed,
        sources: result.sources
      });
    } catch (error) {
      console.error("Indexing error:", error);
      res.status(500).json({
        success: false,
        error: "Failed to index archives"
      });
    }
  });

  // Admin endpoint - trigger indexing for specific source
  app.post("/api/admin/index/:source", async (req, res) => {
    try {
      const { source } = req.params;
      console.log(`Starting indexing for source: ${source}...`);
      const count = await archiveIndexer.indexSource(source);
      
      clearCache();
      
      await notifyWebhookSubscribers("index_complete", { source, itemsIndexed: count });
      
      res.json({
        success: true,
        message: `Indexed ${count} items from ${source}`,
        itemsIndexed: count
      });
    } catch (error) {
      console.error("Source indexing error:", error);
      res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "Failed to index source"
      });
    }
  });

  // Admin endpoint - clear search cache
  app.post("/api/admin/cache/clear", (req, res) => {
    clearCache();
    res.json({
      success: true,
      message: "Cache cleared successfully"
    });
  });

  // Webhook subscription endpoint
  app.post("/api/webhooks/subscribe", (req, res) => {
    try {
      const { url, events } = req.body;
      
      if (!url || !events || !Array.isArray(events)) {
        res.status(400).json({
          success: false,
          error: "url and events array are required"
        });
        return;
      }

      const validEvents = ["new_items", "index_complete", "source_added"];
      const invalidEvents = events.filter((e: string) => !validEvents.includes(e));
      
      if (invalidEvents.length > 0) {
        res.status(400).json({
          success: false,
          error: `Invalid events: ${invalidEvents.join(", ")}. Valid events: ${validEvents.join(", ")}`
        });
        return;
      }

      const id = Math.random().toString(36).substring(2, 15);
      webhookSubscribers.set(id, {
        url,
        events,
        createdAt: new Date()
      });

      res.json({
        success: true,
        message: "Webhook subscription created",
        subscriptionId: id,
        events
      });
    } catch (error) {
      console.error("Webhook subscription error:", error);
      res.status(500).json({
        success: false,
        error: "Failed to create webhook subscription"
      });
    }
  });

  // Webhook unsubscribe endpoint
  app.delete("/api/webhooks/unsubscribe/:id", (req, res) => {
    const { id } = req.params;
    
    if (webhookSubscribers.has(id)) {
      webhookSubscribers.delete(id);
      res.json({
        success: true,
        message: "Webhook subscription removed"
      });
    } else {
      res.status(404).json({
        success: false,
        error: "Subscription not found"
      });
    }
  });

  // List webhook subscriptions
  app.get("/api/webhooks", (req, res) => {
    const subscriptions = Array.from(webhookSubscribers.entries()).map(([id, sub]) => ({
      id,
      url: sub.url,
      events: sub.events,
      createdAt: sub.createdAt.toISOString()
    }));

    res.json({
      success: true,
      data: subscriptions
    });
  });

  // Run initial indexing on server start (only if database is empty)
  setTimeout(async () => {
    try {
      const stats = await storage.getStats();
      if (stats.totalItems === 0) {
        console.log("Database empty, running initial indexing...");
        const result = await archiveIndexer.indexAll();
        console.log(`Initial indexing complete: ${result.totalIndexed} items indexed from ${result.sources.length} sources`);
      }
    } catch (error) {
      console.error("Initial indexing failed:", error);
    }
  }, 3000);

  return httpServer;
}
