import {
  archiveSources,
  archiveItems,
  type ArchiveSource,
  type ArchiveItem,
  type InsertArchiveSource,
  type InsertArchiveItem,
  type SearchQuery,
  type DiscordEmbedItem,
  type ArchiveStats,
  type AdvancedSearchQuery,
} from "@shared/schema";
import { db } from "./db";
import { eq, ilike, and, or, not, sql, desc, count, gte, lte } from "drizzle-orm";

function sanitizeSearchTerm(term: string): string {
  return term
    .replace(/[%_\\]/g, "\\$&")
    .replace(/['"`;]/g, "")
    .substring(0, 100);
}

function parseAdvancedQuery(queryString: string): AdvancedSearchQuery {
  const result: AdvancedSearchQuery = {
    terms: [],
    operator: "AND",
    exclude: [],
    phrase: undefined
  };

  const safeQuery = queryString.substring(0, 500);

  const phraseMatch = safeQuery.match(/"([^"]+)"/);
  if (phraseMatch) {
    result.phrase = sanitizeSearchTerm(phraseMatch[1]);
    queryString = safeQuery.replace(/"([^"]+)"/, "").trim();
  } else {
    queryString = safeQuery;
  }

  if (queryString.toUpperCase().includes(" OR ")) {
    result.operator = "OR";
    const parts = queryString.split(/\s+OR\s+/i);
    result.terms = parts
      .map(p => sanitizeSearchTerm(p.trim()))
      .filter(p => p && !p.startsWith("-"));
    result.exclude = parts
      .filter(p => p.startsWith("-"))
      .map(p => sanitizeSearchTerm(p.substring(1)));
  } else {
    const parts = queryString.split(/\s+AND\s+|\s+/i);
    result.terms = parts
      .filter(p => p && !p.startsWith("-"))
      .map(p => sanitizeSearchTerm(p.trim()));
    result.exclude = parts
      .filter(p => p.startsWith("-"))
      .map(p => sanitizeSearchTerm(p.substring(1).trim()));
  }

  return result;
}

const searchCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000;

function getCacheKey(query: SearchQuery): string {
  return JSON.stringify(query);
}

function getFromCache<T>(key: string): T | null {
  const cached = searchCache.get(key);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data as T;
  }
  if (cached) {
    searchCache.delete(key);
  }
  return null;
}

function setCache<T>(key: string, data: T): void {
  if (searchCache.size > 1000) {
    const firstKey = searchCache.keys().next().value;
    if (firstKey) searchCache.delete(firstKey);
  }
  searchCache.set(key, { data, timestamp: Date.now() });
}

export function clearCache(): void {
  searchCache.clear();
}

export interface IStorage {
  getSource(id: string): Promise<ArchiveSource | undefined>;
  getAllSources(): Promise<ArchiveSource[]>;
  createSource(source: InsertArchiveSource): Promise<ArchiveSource>;
  updateSourceStats(id: string, totalItems: number): Promise<void>;
  updateSourceLastScraped(id: string): Promise<void>;

  getItem(id: string): Promise<ArchiveItem | undefined>;
  createItem(item: InsertArchiveItem): Promise<ArchiveItem>;
  createItems(items: InsertArchiveItem[]): Promise<ArchiveItem[]>;
  searchItems(query: SearchQuery): Promise<{ items: DiscordEmbedItem[]; total: number }>;
  getItemsByCategory(category: string, page: number, limit: number): Promise<{ items: DiscordEmbedItem[]; total: number }>;
  getItemsByYear(year: number, page: number, limit: number): Promise<{ items: DiscordEmbedItem[]; total: number }>;
  getItemsByYearRange(yearFrom: number, yearTo: number, page: number, limit: number): Promise<{ items: DiscordEmbedItem[]; total: number }>;
  getStats(): Promise<ArchiveStats>;
  deleteItemsBySource(sourceId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getSource(id: string): Promise<ArchiveSource | undefined> {
    const [source] = await db.select().from(archiveSources).where(eq(archiveSources.id, id));
    return source || undefined;
  }

  async getAllSources(): Promise<ArchiveSource[]> {
    return db.select().from(archiveSources).where(eq(archiveSources.isActive, "true"));
  }

  async createSource(source: InsertArchiveSource): Promise<ArchiveSource> {
    const [newSource] = await db.insert(archiveSources).values(source).returning();
    return newSource;
  }

  async updateSourceStats(id: string, totalItems: number): Promise<void> {
    await db.update(archiveSources).set({ totalItems }).where(eq(archiveSources.id, id));
  }

  async updateSourceLastScraped(id: string): Promise<void> {
    await db.update(archiveSources).set({ lastScraped: new Date() }).where(eq(archiveSources.id, id));
  }

  async getItem(id: string): Promise<ArchiveItem | undefined> {
    const [item] = await db.select().from(archiveItems).where(eq(archiveItems.id, id));
    return item || undefined;
  }

  async createItem(item: InsertArchiveItem): Promise<ArchiveItem> {
    const [newItem] = await db.insert(archiveItems).values(item).returning();
    return newItem;
  }

  async createItems(items: InsertArchiveItem[]): Promise<ArchiveItem[]> {
    if (items.length === 0) return [];
    const newItems = await db.insert(archiveItems).values(items).returning();
    return newItems;
  }

  async searchItems(query: SearchQuery): Promise<{ items: DiscordEmbedItem[]; total: number }> {
    const cacheKey = getCacheKey(query);
    const cached = getFromCache<{ items: DiscordEmbedItem[]; total: number }>(cacheKey);
    if (cached) {
      return cached;
    }

    const conditions = [];

    if (query.q) {
      const advancedQuery = parseAdvancedQuery(query.q);
      
      if (advancedQuery.phrase) {
        conditions.push(
          or(
            ilike(archiveItems.title, `%${advancedQuery.phrase}%`),
            ilike(archiveItems.description, `%${advancedQuery.phrase}%`)
          )
        );
      }

      if (advancedQuery.terms.length > 0) {
        const termConditions = advancedQuery.terms.map(term =>
          or(
            ilike(archiveItems.title, `%${term}%`),
            ilike(archiveItems.description, `%${term}%`),
            ilike(archiveItems.event, `%${term}%`),
            ilike(archiveItems.topic, `%${term}%`)
          )
        );

        if (advancedQuery.operator === "AND") {
          conditions.push(and(...termConditions));
        } else {
          conditions.push(or(...termConditions));
        }
      }

      if (advancedQuery.exclude && advancedQuery.exclude.length > 0) {
        advancedQuery.exclude.forEach(term => {
          conditions.push(
            and(
              not(ilike(archiveItems.title, `%${term}%`)),
              not(ilike(archiveItems.description, `%${term}%`))
            )
          );
        });
      }
    }

    if (query.category) {
      conditions.push(eq(archiveItems.category, query.category));
    }

    if (query.year) {
      conditions.push(eq(archiveItems.year, query.year));
    }

    if (query.yearFrom) {
      conditions.push(gte(archiveItems.year, query.yearFrom));
    }

    if (query.yearTo) {
      conditions.push(lte(archiveItems.year, query.yearTo));
    }

    if (query.event) {
      conditions.push(ilike(archiveItems.event, `%${query.event}%`));
    }

    if (query.topic) {
      conditions.push(ilike(archiveItems.topic, `%${query.topic}%`));
    }

    if (query.source) {
      conditions.push(eq(archiveItems.sourceId, query.source));
    }

    if (query.collection) {
      conditions.push(ilike(archiveItems.collection, `%${query.collection}%`));
    }

    if (query.author) {
      conditions.push(ilike(archiveItems.author, `%${query.author}%`));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    const offset = (query.page - 1) * query.limit;

    const [totalResult] = await db
      .select({ count: count() })
      .from(archiveItems)
      .where(whereClause);

    const items = await db
      .select({
        id: archiveItems.id,
        title: archiveItems.title,
        description: archiveItems.description,
        year: archiveItems.year,
        category: archiveItems.category,
        sourceId: archiveItems.sourceId,
        sourceUrl: archiveItems.sourceUrl,
        thumbnailUrl: archiveItems.thumbnailUrl,
        event: archiveItems.event,
        topic: archiveItems.topic,
        author: archiveItems.author,
        collection: archiveItems.collection,
      })
      .from(archiveItems)
      .where(whereClause)
      .orderBy(desc(archiveItems.year), desc(archiveItems.indexedAt))
      .limit(query.limit)
      .offset(offset);

    const sources = await db.select().from(archiveSources);
    const sourceMap = new Map(sources.map(s => [s.id, s.name]));

    const discordItems: DiscordEmbedItem[] = items.map(item => ({
      id: item.id,
      title: item.title,
      description: item.description ? (item.description.length > 200 ? item.description.substring(0, 197) + "..." : item.description) : "",
      year: item.year,
      category: item.category,
      source: sourceMap.get(item.sourceId) || "Unknown",
      sourceUrl: item.sourceUrl,
      thumbnailUrl: item.thumbnailUrl,
      event: item.event,
      topic: item.topic,
      author: item.author,
      collection: item.collection,
    }));

    const result = { items: discordItems, total: totalResult.count };
    setCache(cacheKey, result);
    return result;
  }

  async getItemsByCategory(category: string, page: number, limit: number): Promise<{ items: DiscordEmbedItem[]; total: number }> {
    return this.searchItems({ category: category as any, page, limit });
  }

  async getItemsByYear(year: number, page: number, limit: number): Promise<{ items: DiscordEmbedItem[]; total: number }> {
    return this.searchItems({ year, page, limit });
  }

  async getItemsByYearRange(yearFrom: number, yearTo: number, page: number, limit: number): Promise<{ items: DiscordEmbedItem[]; total: number }> {
    return this.searchItems({ yearFrom, yearTo, page, limit });
  }

  async getStats(): Promise<ArchiveStats> {
    const [totalResult] = await db.select({ count: count() }).from(archiveItems);
    
    const categoryStats = await db
      .select({
        category: archiveItems.category,
        count: count(),
      })
      .from(archiveItems)
      .groupBy(archiveItems.category);

    const [sourcesResult] = await db.select({ count: count() }).from(archiveSources).where(eq(archiveSources.isActive, "true"));

    const [lastUpdated] = await db
      .select({ lastScraped: archiveSources.lastScraped })
      .from(archiveSources)
      .orderBy(desc(archiveSources.lastScraped))
      .limit(1);

    const byCategory = {
      photos: 0,
      videos: 0,
      documents: 0,
      books: 0,
    };

    categoryStats.forEach(stat => {
      if (stat.category in byCategory) {
        byCategory[stat.category as keyof typeof byCategory] = stat.count;
      }
    });

    return {
      totalItems: totalResult.count,
      byCategory,
      sources: sourcesResult.count,
      lastUpdated: lastUpdated?.lastScraped?.toISOString() || null,
    };
  }

  async deleteItemsBySource(sourceId: string): Promise<void> {
    await db.delete(archiveItems).where(eq(archiveItems.sourceId, sourceId));
  }
}

export const storage = new DatabaseStorage();
