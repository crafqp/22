import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const categoryEnum = pgEnum("category", ["photos", "videos", "documents", "books"]);

export const archiveSources = pgTable("archive_sources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  url: text("url").notNull(),
  description: text("description"),
  totalItems: integer("total_items").default(0),
  lastScraped: timestamp("last_scraped"),
  isActive: text("is_active").default("true"),
});

export const archiveItems = pgTable("archive_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sourceId: varchar("source_id").notNull().references(() => archiveSources.id),
  externalId: text("external_id"),
  title: text("title").notNull(),
  description: text("description"),
  category: categoryEnum("category").notNull(),
  year: integer("year"),
  event: text("event"),
  topic: text("topic"),
  sourceUrl: text("source_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  author: text("author"),
  publisher: text("publisher"),
  duration: text("duration"),
  pageCount: integer("page_count"),
  fileType: text("file_type"),
  collection: text("collection"),
  tags: text("tags").array(),
  indexedAt: timestamp("indexed_at").defaultNow(),
});

export const archiveSourcesRelations = relations(archiveSources, ({ many }) => ({
  items: many(archiveItems),
}));

export const archiveItemsRelations = relations(archiveItems, ({ one }) => ({
  source: one(archiveSources, {
    fields: [archiveItems.sourceId],
    references: [archiveSources.id],
  }),
}));

export const insertArchiveSourceSchema = createInsertSchema(archiveSources).omit({
  id: true,
  lastScraped: true,
});

export const insertArchiveItemSchema = createInsertSchema(archiveItems).omit({
  id: true,
  indexedAt: true,
});

export type InsertArchiveSource = z.infer<typeof insertArchiveSourceSchema>;
export type ArchiveSource = typeof archiveSources.$inferSelect;

export type InsertArchiveItem = z.infer<typeof insertArchiveItemSchema>;
export type ArchiveItem = typeof archiveItems.$inferSelect;

export const searchQuerySchema = z.object({
  q: z.string().optional(),
  category: z.enum(["photos", "videos", "documents", "books"]).optional(),
  year: z.coerce.number().optional(),
  yearFrom: z.coerce.number().optional(),
  yearTo: z.coerce.number().optional(),
  event: z.string().optional(),
  topic: z.string().optional(),
  source: z.string().optional(),
  collection: z.string().optional(),
  author: z.string().optional(),
  page: z.coerce.number().default(1),
  limit: z.coerce.number().default(10).refine((val) => val <= 25, {
    message: "Limit cannot exceed 25",
  }),
});

export interface AdvancedSearchQuery {
  terms: string[];
  operator: "AND" | "OR";
  exclude?: string[];
  phrase?: string;
}

export type SearchQuery = z.infer<typeof searchQuerySchema>;

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
  };
  meta?: {
    lastUpdated: string;
    source: string;
  };
}

export interface DiscordEmbedItem {
  id: string;
  title: string;
  description: string;
  year: number | null;
  category: string;
  source: string;
  sourceUrl: string;
  thumbnailUrl: string | null;
  event: string | null;
  topic: string | null;
  author: string | null;
  collection: string | null;
}

export interface ArchiveStats {
  totalItems: number;
  byCategory: {
    photos: number;
    videos: number;
    documents: number;
    books: number;
  };
  sources: number;
  lastUpdated: string | null;
}
