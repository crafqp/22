# Palestine Archive API - Backend Service Design Guidelines

## Project Scope Clarification
This is a **backend API-only service** with no user interface. The API serves as the data engine for a Discord bot, with no public-facing web pages.

---

## API Response Design for Discord Integration

### Response Structure Philosophy
Responses must be optimized for Discord's embed system and character limits while maintaining rich, informative content.

### Core Response Elements

**Search Results Format:**
- Maximum 10 results per query for Discord embed limits
- Each result includes: title, description (max 200 chars), year, category, source, direct URL
- Thumbnail URLs for visual media (photos, video covers)
- Hierarchical metadata: event → year → topic

**Category Organization:**
- Photos: Include thumbnail URLs, dimensions, photographer credit
- Videos: Include duration, thumbnail, platform (YouTube/Vimeo links)
- Documents: Include page count, file type, preview URL
- Books: Include author, publisher, page count, ISBN when available

**Filter Parameters:**
- Year range (e.g., 1948-1967)
- Event tags (Nakba, Intifadas, etc.)
- Source archives (Palestinian Museum, UNRWA, Poster Project)
- Topic categories (daily life, resistance, culture, displacement)

### API Endpoint Design

**Core Endpoints:**
- `/api/search` - Full-text search with filters
- `/api/category/{type}` - Browse by category (photos/videos/documents/books)
- `/api/timeline/{year}` - Results by specific year or range
- `/api/sources` - List all integrated archive sources
- `/api/stats` - Total indexed items, last update time

**Response Optimization:**
- Paginated results (10 items default, max 25)
- Include "next_page" tokens for continuation
- Rich metadata for Discord embeds (title, description, image, URL)
- Source attribution prominently included

### Data Quality Standards

**Metadata Requirements:**
- All items must have: title, year, source archive, category
- Descriptions should be concise but informative (50-200 chars optimal for Discord)
- Dates formatted as ISO 8601 for consistency
- URLs must be direct links to archive sources, not intermediary pages

**Archive Attribution:**
- Every response includes source name and URL
- Credit original archives (Palestinian Museum, UNRWA, etc.)
- Include collection names when available

---

## Technical Considerations

**Performance:**
- Response time under 500ms for searches
- Efficient pagination for large result sets
- Caching for popular queries

**Updates:**
- Daily metadata refresh from source archives
- Webhook endpoint for Discord bot to check for new content
- Version endpoint to track archive updates

This API serves as an invisible but powerful engine, delivering Palestine's historical archive directly to Discord users through structured, searchable, and respectfully attributed data.